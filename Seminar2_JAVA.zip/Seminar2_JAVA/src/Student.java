import java.util.Arrays;

class Student {
    int idStudent;
    String nume;
    String grupa;
    int anul;
    Nota[] note;

    public Student(int idStudent, String nume, String grupa, int anul) {
        this.idStudent = idStudent;
        this.nume = nume;
        this.grupa = grupa;
        this.anul = anul;
        this.note= new Nota[0];
    }

    public int getIdStudent() {
        return idStudent;
    }

    public void setIdStudent(int idStudent) {
        this.idStudent = idStudent;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getGrupa() {
        return grupa;
    }

    public void setGrupa(String grupa) {
        this.grupa = grupa;
    }

    public int getAnul() {
        return anul;
    }

    public void setAnul(int anul) {
        this.anul = anul;
    }

    public Nota[] getNote() {
        return note;
    }

    public void adaugaNota(Nota nota){
        for( var notaExistenta: note){
            if(notaExistenta.getNumeDisciplina().equals(nota.getNumeDisciplina())){
                notaExistenta.setNota(nota.getNota());
                return;
            }
        }
        note=(Nota[]) Arrays.copyOf(note,note.length+1);
        note[note.length-1]=nota;

    }

    @Override
    public String toString() {
        var builder= new StringBuilder();
        builder.append(String.format("#%2d %-10s grupa %s an %d%n", idStudent,nume,grupa,anul));
        for(var nota:note){
            builder.append("  "+nota+"\n");
        }
        return builder.toString();
    }
}
