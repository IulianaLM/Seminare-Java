import java.util.Scanner;

public class Program {
    public static void main(String[] args){
//        var nota=new Nota("Java", 8);
//        nota.setNota(10);
//        System.out.println(nota);
//
//        var ion=new Student(13,"Ion","1001",3);
//        ion.adaugaNota(new Nota("PAW",8));
//        ion.adaugaNota(new Nota("Java",10));
//        ion.adaugaNota(new Nota("PAW",9));
//        System.out.println(ion);


        //Ca sa citim datele din fisierul date.txt dam click dreapta pe semnul de run de la clasa
        // dupa Modify run configuration si dupa dam pe Modify option si dupa adaugam fisierul date.txt
        var scanner= new Scanner(System.in);
        int n= Integer.parseInt(scanner.nextLine());
        var studenti=new Student[n];
//        System.out.println(n);
        for(var index=0;index< n;index++){
            var linie = scanner.nextLine().split(",");
            var student=new Student(
                    Integer.parseInt(linie[0]),
                    linie[1],
                    linie[2],
                    Integer.parseInt(linie[3])
            );
            studenti[index]=student;
            linie = scanner.nextLine().split(",");
            for(var j=0;j<linie.length;j+=2){
                student.adaugaNota(new Nota(
                        linie[j], Integer.parseInt(linie[j+1])
                ));
            }

        }
        for(var student:studenti){
            System.out.println(student);
        }
    }
}
