import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProgramStocuri {

    static Map<Produs,List<Tranzactie>> produse= new HashMap<>();
    static void AdaugaProdus(int cod, String denumire){
        if(produse.containsKey(new Produs(cod))){
            throw new IllegalArgumentException("Produsul existe!");
        }else{
            produse.put(new Produs(cod,denumire),new ArrayList<>());
        }
    }

    static void AdaugaTranzactie(TipTranzactie tip,LocalDate data,int codProdus,int cantitate){

        var produs=new Produs(codProdus);
        if(produse.containsKey(produs)){
            produse.get(produs).add(
                    new Tranzactie(tip,data,codProdus,cantitate));

        }else{
            throw new IllegalArgumentException("produsul nu exista");
        }
    }

    public static void main(String[] args){
//        var mere= new Produs(1,"Mere");
//        System.out.println(mere);
//        if( mere.equals(new Produs(1))){
//            System.out.println("Sunt egale");
//        }
//        var tranzactie=new Tranzactie(TipTranzactie.IESIRE, LocalDate.of(2025,1,12),
//                1,
//                12);
//        System.out.println(tranzactie);
        AdaugaProdus(1,"A");
        AdaugaProdus(0,"C");
        AdaugaProdus(2,"B");
        AdaugaTranzactie(TipTranzactie.INTRARE,LocalDate.of(2020,1,12),
                1,10);
        AdaugaTranzactie(TipTranzactie.INTRARE,LocalDate.of(2020,5,5),
                2,10);
        AdaugaTranzactie(TipTranzactie.IESIRE,LocalDate.of(2020,3,11),
                0,10);
        AdaugaTranzactie(TipTranzactie.IESIRE,LocalDate.of(2020,4,20),
                1,20);
        for(var entry: produse.entrySet()){
            System.out.println(entry);
            var produs = entry.getKey();
            var tranzactii=entry.getValue();
            var stoc= 0;
            for(var tranzactie: tranzactii){
                stoc += tranzactie.getCantitate()* tranzactie.getTip().semn();
            }
            System.out.printf("#%d %-5s %d bucati%n",
                    produs.getCod(),produs.getDenumire(),stoc);

        }
    }
}
